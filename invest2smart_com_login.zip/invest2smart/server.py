#!/usr/bin/env python3
"""
server.py — Backend Invest2Smart
Autenticação com email/senha + banco SQLite para histórico por usuário
"""

import sqlite3
import hashlib
import hmac
import os
import json
import secrets
from datetime import datetime
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse, parse_qs

DB_PATH = os.path.join(os.path.dirname(__file__), "invest2smart.db")
PORT = 5000

# ──────────────────────────────────────────────────────────────
# BANCO DE DADOS
# ──────────────────────────────────────────────────────────────

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS usuarios (
            id        INTEGER PRIMARY KEY AUTOINCREMENT,
            nome      TEXT    NOT NULL,
            email     TEXT    NOT NULL UNIQUE,
            senha     TEXT    NOT NULL,
            criado_em TEXT    NOT NULL DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS simulacoes (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            usuario_id    INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
            investimento  TEXT    NOT NULL,
            indexador     TEXT    NOT NULL,
            valor_inicial REAL    NOT NULL,
            aporte        REAL    NOT NULL DEFAULT 0,
            meses         INTEGER NOT NULL,
            cdi           REAL    NOT NULL,
            ipca          REAL    NOT NULL,
            prefix        REAL    NOT NULL DEFAULT 0,
            montante      REAL    NOT NULL,
            montante_liq  REAL    NOT NULL,
            lucro_liq     REAL    NOT NULL,
            rent_liq      REAL    NOT NULL,
            imposto       REAL    NOT NULL DEFAULT 0,
            sharpe        REAL    NOT NULL DEFAULT 0,
            criado_em     TEXT    NOT NULL DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS sessoes (
            token      TEXT    PRIMARY KEY,
            usuario_id INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
            criado_em  TEXT    NOT NULL DEFAULT (datetime('now'))
        );
    """)
    conn.commit()
    conn.close()

# ──────────────────────────────────────────────────────────────
# HELPERS
# ──────────────────────────────────────────────────────────────

def hash_senha(senha: str) -> str:
    salt = "invest2smart_tcc_2024"
    return hashlib.pbkdf2_hmac("sha256", senha.encode(), salt.encode(), 200_000).hex()

def criar_sessao(usuario_id: int) -> str:
    token = secrets.token_hex(32)
    conn = get_db()
    conn.execute("INSERT INTO sessoes (token, usuario_id) VALUES (?,?)", (token, usuario_id))
    conn.commit()
    conn.close()
    return token

def autenticar_token(token: str):
    if not token:
        return None
    conn = get_db()
    row = conn.execute(
        "SELECT u.* FROM sessoes s JOIN usuarios u ON u.id = s.usuario_id WHERE s.token=?",
        (token,)
    ).fetchone()
    conn.close()
    return dict(row) if row else None

def json_response(handler, status, data):
    body = json.dumps(data, ensure_ascii=False).encode()
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Content-Length", len(body))
    handler.send_header("Access-Control-Allow-Origin", "*")
    handler.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
    handler.send_header("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS")
    handler.end_headers()
    handler.wfile.write(body)

def get_token(handler):
    auth = handler.headers.get("Authorization", "")
    return auth.replace("Bearer ", "").strip() if auth.startswith("Bearer ") else None

# ──────────────────────────────────────────────────────────────
# HTTP HANDLER
# ──────────────────────────────────────────────────────────────

class Handler(BaseHTTPRequestHandler):

    def log_message(self, fmt, *args):
        print(f"[{datetime.now().strftime('%H:%M:%S')}] {fmt % args}")

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS")
        self.end_headers()

    def read_body(self):
        length = int(self.headers.get("Content-Length", 0))
        return json.loads(self.rfile.read(length)) if length else {}

    def do_POST(self):
        path = urlparse(self.path).path

        # ── CADASTRO ──────────────────────────────────────────
        if path == "/api/cadastro":
            body = self.read_body()
            nome  = (body.get("nome", "") or "").strip()
            email = (body.get("email", "") or "").strip().lower()
            senha = body.get("senha", "") or ""

            if not nome or not email or not senha:
                return json_response(self, 400, {"erro": "Preencha todos os campos."})
            if len(senha) < 6:
                return json_response(self, 400, {"erro": "A senha deve ter pelo menos 6 caracteres."})
            if "@" not in email:
                return json_response(self, 400, {"erro": "E-mail inválido."})

            conn = get_db()
            existe = conn.execute("SELECT id FROM usuarios WHERE email=?", (email,)).fetchone()
            if existe:
                conn.close()
                return json_response(self, 409, {"erro": "E-mail já cadastrado."})

            cur = conn.execute(
                "INSERT INTO usuarios (nome, email, senha) VALUES (?,?,?)",
                (nome, email, hash_senha(senha))
            )
            uid = cur.lastrowid
            conn.commit()
            conn.close()

            token = criar_sessao(uid)
            return json_response(self, 201, {"token": token, "nome": nome, "email": email})

        # ── LOGIN ─────────────────────────────────────────────
        elif path == "/api/login":
            body  = self.read_body()
            email = (body.get("email", "") or "").strip().lower()
            senha = body.get("senha", "") or ""

            conn = get_db()
            user = conn.execute("SELECT * FROM usuarios WHERE email=?", (email,)).fetchone()
            conn.close()

            if not user or user["senha"] != hash_senha(senha):
                return json_response(self, 401, {"erro": "E-mail ou senha incorretos."})

            token = criar_sessao(user["id"])
            return json_response(self, 200, {"token": token, "nome": user["nome"], "email": user["email"]})

        # ── LOGOUT ────────────────────────────────────────────
        elif path == "/api/logout":
            token = get_token(self)
            if token:
                conn = get_db()
                conn.execute("DELETE FROM sessoes WHERE token=?", (token,))
                conn.commit()
                conn.close()
            return json_response(self, 200, {"ok": True})

        # ── SALVAR SIMULAÇÃO ──────────────────────────────────
        elif path == "/api/simulacoes":
            user = autenticar_token(get_token(self))
            if not user:
                return json_response(self, 401, {"erro": "Não autorizado."})

            body = self.read_body()
            try:
                conn = get_db()
                conn.execute("""
                    INSERT INTO simulacoes
                        (usuario_id, investimento, indexador, valor_inicial, aporte,
                         meses, cdi, ipca, prefix, montante, montante_liq,
                         lucro_liq, rent_liq, imposto, sharpe)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """, (
                    user["id"],
                    body["investimento"], body["indexador"],
                    body["valor_inicial"], body.get("aporte", 0),
                    body["meses"], body["cdi"], body["ipca"], body.get("prefix", 0),
                    body["montante"], body["montante_liq"],
                    body["lucro_liq"], body["rent_liq"],
                    body.get("imposto", 0), body.get("sharpe", 0),
                ))
                conn.commit()
                conn.close()
                return json_response(self, 201, {"ok": True})
            except Exception as e:
                return json_response(self, 400, {"erro": str(e)})

        else:
            json_response(self, 404, {"erro": "Rota não encontrada."})

    def do_GET(self):
        path = urlparse(self.path).path

        # ── VERIFICAR TOKEN ───────────────────────────────────
        if path == "/api/me":
            user = autenticar_token(get_token(self))
            if not user:
                return json_response(self, 401, {"erro": "Não autorizado."})
            return json_response(self, 200, {"nome": user["nome"], "email": user["email"]})

        # ── LISTAR HISTÓRICO ──────────────────────────────────
        elif path == "/api/simulacoes":
            user = autenticar_token(get_token(self))
            if not user:
                return json_response(self, 401, {"erro": "Não autorizado."})

            conn = get_db()
            rows = conn.execute("""
                SELECT investimento, indexador, valor_inicial, aporte, meses,
                       montante_liq, lucro_liq, rent_liq, imposto, sharpe,
                       criado_em
                FROM simulacoes
                WHERE usuario_id=?
                ORDER BY id DESC
                LIMIT 50
            """, (user["id"],)).fetchall()
            conn.close()

            data = [dict(r) for r in rows]
            return json_response(self, 200, data)

        # ── LIMPAR HISTÓRICO ──────────────────────────────────
        elif path == "/api/simulacoes/limpar":
            # Usaremos GET simples aqui para compatibilidade com fetch simples
            user = autenticar_token(get_token(self))
            if not user:
                return json_response(self, 401, {"erro": "Não autorizado."})
            conn = get_db()
            conn.execute("DELETE FROM simulacoes WHERE usuario_id=?", (user["id"],))
            conn.commit()
            conn.close()
            return json_response(self, 200, {"ok": True})

        else:
            # Serve static files
            static_path = os.path.join(os.path.dirname(__file__), path.lstrip("/"))
            if os.path.isfile(static_path):
                ext = os.path.splitext(static_path)[1]
                types = {".html":"text/html",".js":"text/javascript",".css":"text/css",
                         ".png":"image/png",".jpg":"image/jpeg",".ico":"image/x-icon"}
                ctype = types.get(ext, "application/octet-stream")
                with open(static_path, "rb") as f:
                    data = f.read()
                self.send_response(200)
                self.send_header("Content-Type", ctype)
                self.send_header("Content-Length", len(data))
                self.end_headers()
                self.wfile.write(data)
            elif path == "/" or path == "":
                index = os.path.join(os.path.dirname(__file__), "index.html")
                with open(index, "rb") as f:
                    data = f.read()
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", len(data))
                self.end_headers()
                self.wfile.write(data)
            else:
                json_response(self, 404, {"erro": "Não encontrado."})

    def do_DELETE(self):
        path = urlparse(self.path).path
        if path == "/api/simulacoes":
            user = autenticar_token(get_token(self))
            if not user:
                return json_response(self, 401, {"erro": "Não autorizado."})
            conn = get_db()
            conn.execute("DELETE FROM simulacoes WHERE usuario_id=?", (user["id"],))
            conn.commit()
            conn.close()
            return json_response(self, 200, {"ok": True})
        json_response(self, 404, {"erro": "Rota não encontrada."})


# ──────────────────────────────────────────────────────────────
# MAIN
# ──────────────────────────────────────────────────────────────

if __name__ == "__main__":
    init_db()
    print(f"🚀  Invest2Smart rodando em http://localhost:{PORT}")
    print(f"📂  Banco de dados: {DB_PATH}")
    print("   Pressione Ctrl+C para encerrar.\n")
    server = HTTPServer(("0.0.0.0", PORT), Handler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n⏹  Servidor encerrado.")
