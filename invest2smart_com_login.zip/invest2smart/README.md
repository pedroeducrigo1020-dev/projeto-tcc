# Invest2Smart — com Login e Banco de Dados

## Estrutura do projeto

```
invest2smart/
├── server.py          ← Backend Python (HTTP + SQLite)
├── index.html         ← Frontend completo (simulador + login)
├── invest2smart.db    ← Criado automaticamente ao iniciar
├── assets/
│   ├── claro.png
│   └── escuro.png
└── README.md
```

## Como executar

### 1. Instalar dependências
```bash
pip install werkzeug
```
*(Python 3.8+ e a biblioteca `http.server` padrão já são suficientes)*

### 2. Iniciar o servidor
```bash
cd invest2smart
python server.py
```

Saída esperada:
```
🚀  Invest2Smart rodando em http://localhost:5000
📂  Banco de dados: /caminho/invest2smart.db
```

### 3. Abrir no navegador
```
http://localhost:5000
```

---

## Banco de dados (SQLite)

### Tabelas criadas automaticamente

#### `usuarios`
| Coluna      | Tipo    | Descrição                  |
|-------------|---------|----------------------------|
| id          | INTEGER | Chave primária             |
| nome        | TEXT    | Nome do usuário            |
| email       | TEXT    | E-mail único               |
| senha       | TEXT    | Hash PBKDF2-SHA256         |
| criado_em   | TEXT    | Data/hora de cadastro      |

#### `simulacoes`
| Coluna        | Tipo    | Descrição                        |
|---------------|---------|----------------------------------|
| id            | INTEGER | Chave primária                   |
| usuario_id    | INTEGER | FK → usuarios                    |
| investimento  | TEXT    | Nome (CDB, LCI, Tesouro...)      |
| indexador     | TEXT    | CDI, IPCA, Prefixado...          |
| valor_inicial | REAL    | Aporte inicial                   |
| aporte        | REAL    | Aporte mensal                    |
| meses         | INTEGER | Prazo em meses                   |
| cdi / ipca / prefix | REAL | Taxas utilizadas            |
| montante      | REAL    | Montante bruto                   |
| montante_liq  | REAL    | Montante líquido (após IR)       |
| lucro_liq     | REAL    | Lucro líquido                    |
| rent_liq      | REAL    | Rentabilidade líquida (%)        |
| imposto       | REAL    | IR pago                          |
| sharpe        | REAL    | Índice Sharpe                    |
| criado_em     | TEXT    | Data/hora da simulação           |

#### `sessoes`
| Coluna      | Tipo    | Descrição                  |
|-------------|---------|----------------------------|
| token       | TEXT    | Token aleatório (64 hex)   |
| usuario_id  | INTEGER | FK → usuarios              |
| criado_em   | TEXT    | Data/hora de criação       |

---

## Endpoints da API

| Método | Rota                    | Auth? | Descrição                        |
|--------|-------------------------|-------|----------------------------------|
| POST   | /api/cadastro           | ✗     | Criar conta                      |
| POST   | /api/login              | ✗     | Fazer login → retorna token      |
| POST   | /api/logout             | ✓     | Encerrar sessão                  |
| GET    | /api/me                 | ✓     | Verificar sessão atual           |
| POST   | /api/simulacoes         | ✓     | Salvar simulação                 |
| GET    | /api/simulacoes         | ✓     | Listar histórico do usuário      |
| DELETE | /api/simulacoes         | ✓     | Limpar histórico do usuário      |

---

## Segurança

- Senhas armazenadas com **PBKDF2-SHA256** (200.000 iterações)
- Sessões por **token aleatório de 64 bytes** (hex)
- Cada usuário vê **apenas suas próprias simulações**
- Sem sessão ativa → fallback para histórico local (localStorage)

---

## Modo offline

Sem o servidor rodando, o app funciona normalmente em modo local:
- Histórico salvo no `localStorage` do navegador
- Ao entrar na conta, o histórico da API é carregado automaticamente
